<?php
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/quantize-gd.php';
require_once __DIR__ . '/quantize-palette.php';
