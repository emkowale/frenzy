/*
 * File: assets/js/uploader.js
 * Description: Python-only uploader — shows spinner, posts to vectorize endpoint, opens popup, emits render event on approve
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11
 */
(function () {
  const NS = (window.DMI = window.DMI || {});
  if (NS.__uploaderReady) return;
  NS.__uploaderReady = true;

  function bind() {
    // Button → open file dialog
    jQuery(document).off('click.dmiUpload', '#dmi-upload-button')
      .on('click.dmiUpload', '#dmi-upload-button', function (e) {
        e.preventDefault(); e.stopPropagation();
        if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
        const input = document.getElementById('dmi-upload');
        if (input) input.click();
      });

    // File selected → send to Python vectorizer
    jQuery(document).off('change.dmiUpload', '#dmi-upload')
      .on('change.dmiUpload', '#dmi-upload', function () {
        const file = this.files && this.files[0];
        if (!file) return;

        // Spinner immediately
        NS.spinner && NS.spinner.show('Reading file…');

        const reader = new FileReader();
        reader.onload = function (ev) {
          const originalDataURL = ev.target.result;

          const formData = new FormData();
          formData.append('action', 'dmi_vectorize_upload');
          formData.append('_ajax_nonce', (window.dmi_ajax && dmi_ajax.nonce) || '');
          formData.append('image', file);

          const inkSelect = document.getElementById('dmi-ink-color-count');
          if (inkSelect) formData.append('ink_colors', inkSelect.value || 2);

          // Optional glow removal:
          // formData.append('bg_thresh', 35);

          NS.spinner && NS.spinner.update('Uploading…');

          jQuery.ajax({
            url: (window.dmi_ajax && dmi_ajax.ajax_url) || '/wp-admin/admin-ajax.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function () {
              const xhr = jQuery.ajaxSettings.xhr();
              if (xhr && xhr.upload) {
                xhr.upload.addEventListener('progress', function (e) {
                  if (e.lengthComputable) {
                    const pct = Math.round((e.loaded / e.total) * 100);
                    NS.spinner && NS.spinner.update(`Uploading… ${pct}%`);
                  }
                });
              }
              return xhr;
            },
            beforeSend: function () {
              setTimeout(() => NS.spinner && NS.spinner.update('Optimizing (no dithering)…'), 50);
            },
            success: function (resp) {
              if (resp && resp.success && resp.data && resp.data.preview_url) {
                const optURL = resp.data.preview_url;
                const hexes  = resp.data.color_hexes || [];
                setTimeout(() => {
                  NS.spinner && NS.spinner.hide();
                  NS.popup.openOptimizationPopup(originalDataURL, optURL, hexes, {
                    onApprove: ({ optimizedURL }) => {
                      const mockupUUID      = document.getElementById('dmi-mockup-uuid')?.value;
                      const smartObjectUUID = document.getElementById('dmi-smartobject-uuid')?.value;
                      const inkSel          = document.getElementById('dmi-ink-color-count');
                      const colorCount      = inkSel ? parseInt(inkSel.value || '2', 10) : 2;

                      if (!mockupUUID || !smartObjectUUID || !optimizedURL) {
                        alert('Missing mockup data or image.');
                        return;
                      }

                      jQuery(document).trigger('dmi:imageReadyForRender', [{
                        mockup_uuid: mockupUUID,
                        smart_objects: [{ uuid: smartObjectUUID, image_url: optimizedURL }],
                        color_count: colorCount
                      }]);
                    },
                    onCancel: () => { /* no-op */ }
                  });
                }, 100);
              } else {
                console.error('Vectorize error:', resp);
                NS.spinner && NS.spinner.hide();
                alert('× Error vectorizing image.');
              }
            },
            error: function (_x, _s, err) {
              console.error('Vectorize AJAX error:', err);
              NS.spinner && NS.spinner.hide();
              alert('× Error vectorizing image.');
            }
          });
        };

        reader.readAsDataURL(file);
        // allow selecting same file again later
        this.value = '';
      });
  }

  jQuery(bind);
  NS.uploader = { bind };
})();
