/*
 * File: assets/js/ui-init.js
 * Description: Initializes approval UI and render handoff (NO upload bindings here)
 * Plugin: Dynamic Mockups Integration
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11 18:05 EDT
 */

(function () {
  // Delegated handlers survive DOM changes and avoid double-binding
  jQuery(function ($) {
    console.log('✅ DMI UI Init: approval-only mode');

    // --- React to the popup's success (from upload-handler.js) ---
    // detail: { simplifiedURL, originalDataURL, hexList }
    document.addEventListener('dmi:imageUploaded', function (ev) {
      const detail = ev.detail || {};
      const { simplifiedURL, originalDataURL, hexList } = detail;

      if (!simplifiedURL) {
        console.warn('[DMI] imageUploaded missing simplifiedURL');
        return;
      }

      // Save for Continue button
      window.dmi_uploadedImageUrl = simplifiedURL;

      // Populate approval UI (these IDs exist in frontend-ui.php)
      const previewContainer  = document.getElementById('dmi-approval-container');
      const previewImage      = document.getElementById('dmi-preview-image');
      const originalImage     = document.getElementById('dmi-original-image');
      const countEl           = document.getElementById('dmi-color-count-display');
      const hiddenCount       = document.getElementById('dmi_color_count');
      const hiddenHexes       = document.getElementById('dmi_color_hexes');
      const swatchContainer   = document.getElementById('dmi-color-swatches');

      if (previewImage)  previewImage.src  = simplifiedURL;
      if (originalImage) originalImage.src = originalDataURL || '';

      const count = Array.isArray(hexList) ? hexList.length : '';
      if (countEl)     countEl.textContent = count;
      if (hiddenCount) hiddenCount.value   = count;
      if (hiddenHexes) hiddenHexes.value   = Array.isArray(hexList) ? hexList.join(',') : '';

      if (swatchContainer) {
        swatchContainer.innerHTML = '';
        if (Array.isArray(hexList)) {
          hexList.forEach(hex => {
            const sw = document.createElement('div');
            sw.style.width = '20px';
            sw.style.height = '20px';
            sw.style.border = '1px solid #ccc';
            sw.style.backgroundColor = hex;
            sw.title = hex;
            swatchContainer.appendChild(sw);
          });
        }
      }

      if (previewContainer) {
        previewContainer.style.display = 'block';
      }

      // Ensure checkbox/continue are reset each time
      const approvalCheckbox = document.getElementById('dmi-approval-check');
      const continueBtn      = document.getElementById('dmi-approval-continue');
      if (approvalCheckbox) approvalCheckbox.checked = false;
      if (continueBtn)      continueBtn.disabled = true;
    }, { once: false });

    // --- Approval checkbox enables Continue ---
    $(document).off('change.dmi', '#dmi-approval-check')
      .on('change.dmi', '#dmi-approval-check', function () {
        $('#dmi-approval-continue').prop('disabled', !this.checked);
      });

    // --- Cancel hides approval and resets ---
    $(document).off('click.dmi', '#dmi-approval-cancel')
      .on('click.dmi', '#dmi-approval-cancel', function () {
        $('#dmi-approval-container').hide();
        $('#dmi-approval-check').prop('checked', false);
        $('#dmi-approval-continue').prop('disabled', true);
      });

    // --- Continue triggers render (no upload triggering here) ---
    $(document).off('click.dmi', '#dmi-approval-continue')
      .on('click.dmi', '#dmi-approval-continue', function () {
        const imageUrl       = window.dmi_uploadedImageUrl;
        const mockupUUID     = $('#dmi-mockup-uuid').val();
        const smartObjectUUID= $('#dmi-smartobject-uuid').val();
        const inkColorCount  = $('#dmi-ink-color-count').val() || 2;

        if (!imageUrl || !mockupUUID || !smartObjectUUID) {
          alert('Missing mockup data or image.');
          return;
        }

        // Spinner overlay
        if (!$('#dmi-modal-spinner-overlay').length) {
          $('body').append(`
            <div id="dmi-modal-spinner-overlay">
              <div class="dmi-modal-spinner-box">
                <img src="https://thebeartraxs.com/wp-content/uploads/2025/04/Bear-Traxs-Logo-favicon-70px-x-70px.png" alt="Bear Traxs Logo">
                <p>Processing your image...</p>
                <div class="dmi-modal-spinner"></div>
              </div>
            </div>
          `);
        }

        // Emit a single render event used by render-handler.js
        $(document).trigger('dmi:imageReadyForRender', [{
          mockup_uuid: mockupUUID,
          smart_objects: [{ uuid: smartObjectUUID, image_url: imageUrl }],
          color_count: parseInt(inkColorCount, 10)
        }]);
      });

    // 🔥 IMPORTANT: Do NOT bind #dmi-upload-button or #dmi-upload here.
    // Upload flow is fully owned by assets/js/upload-handler.js to prevent double prompts.
  });
})();
