/*
 * File: assets/js/dmi-debug.js
 * Description: Lightweight debugger for the DMI frontend flow
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11
 */

(function () {
  const NS = (window.DMI = window.DMI || {});
  if (NS.__debugReady) return;
  NS.__debugReady = true;

  // --- basic logger with timestamps
  function ts() {
    const d = new Date();
    return d.toISOString().split('T')[1].replace('Z','');
  }
  function log(level, msg, data) {
    const line = `%c[DMI][${ts()}][${level}]`;
    const css = level === 'ERR' ? 'color:#b00020;font-weight:700' :
                level === 'WARN'? 'color:#b36b00;font-weight:700' :
                level === 'OK'  ? 'color:#00796b;font-weight:700' :
                                  'color:#37474f';
    if (data !== undefined) {
      console.log(line, css, msg, data);
    } else {
      console.log(line, css, msg);
    }
  }
  const ok   = (m,d)=>log('OK',m,d);
  const info = (m,d)=>log('INF',m,d);
  const warn = (m,d)=>log('WARN',m,d);
  const err  = (m,d)=>log('ERR',m,d);

  // --- version probe (reads ?ver= from script tags)
  function scriptVerContains(pathPart) {
    const el = Array.from(document.scripts).find(s => (s.src||'').includes(pathPart));
    if (!el) return null;
    const m = /[?&]ver=([^&]+)/.exec(el.src);
    return m ? m[1] : '(no ver)';
  }

  function getAttrState() {
    const form = document.querySelector('form.variations_form') || document.querySelector('form.cart');
    if (!form) return { hasForm:false, selects:[], allSelected:true };
    const selects = Array.from(form.querySelectorAll('.variations select')).map(sel => ({
      name: sel.name || sel.id || '(unnamed)',
      value: sel.value || ''
    }));
    const allSelected = selects.every(s => s.value && s.value !== '');
    return { hasForm:true, selects, allSelected };
  }

  // --- public dump
  function debugDump() {
    const state = {
      modules: {
        spinner: !!NS.spinner,
        popup: !!NS.popup,
        uploader: !!NS.uploader,
        render: !!NS.render
      },
      versions: {
        popup: scriptVerContains('assets/js/popup.js'),
        uploader: scriptVerContains('assets/js/uploader.js'),
        render: scriptVerContains('assets/js/render-handler.js'),
        guard: scriptVerContains('assets/js/attributes-guard.js'),
        spinner: scriptVerContains('assets/js/spinner.js'),
        uiInit: scriptVerContains('assets/js/ui-init.js')
      },
      uuids: {
        mockup: document.getElementById('dmi-mockup-uuid')?.value || null,
        smart:  document.getElementById('dmi-smartobject-uuid')?.value || null
      },
      pendingPayload: NS.render && NS.render.pendingPayload ? {
        hasPayload: true,
        image_url: NS.render.pendingPayload.smart_objects?.[0]?.image_url || null,
        color_count: NS.render.pendingPayload.color_count
      } : { hasPayload:false },
      attributes: getAttrState()
    };
    ok('debugDump()', state);
    return state;
  }

  // --- manual triggers for testing
  function force(eventName) {
    if (eventName === 'artApproved') {
      const mockupUUID = document.getElementById('dmi-mockup-uuid')?.value;
      const smartUUID  = document.getElementById('dmi-smartobject-uuid')?.value;
      const payload = { mockup_uuid: mockupUUID, smart_objects: [{ uuid: smartUUID, image_url: 'TEST_URL' }], color_count: 2 };
      jQuery(document).trigger('dmi:artApproved', [payload]);
      ok('Forced dmi:artApproved', payload);
    } else if (eventName === 'triggerRender') {
      jQuery(document).trigger('dmi:triggerRender');
      ok('Forced dmi:triggerRender');
    } else {
      warn('force(): unknown event', eventName);
    }
  }

  // --- Event listeners (NEW & LEGACY)
  jQuery(function ($) {
    $(document)
      .on('dmi:artApproved.dmiDebug', function (_e, payload) {
        ok('EVENT dmi:artApproved', {
          hasPayload: !!payload,
          image_url: payload?.smart_objects?.[0]?.image_url || null,
          color_count: payload?.color_count
        });
      })
      .on('dmi:attributesPhaseReady.dmiDebug', function () {
        ok('EVENT dmi:attributesPhaseReady');
      })
      .on('dmi:triggerRender.dmiDebug', function () {
        ok('EVENT dmi:triggerRender');
      })
      .on('dmi:renderComplete.dmiDebug', function (_e, data) {
        ok('EVENT dmi:renderComplete', data);
      })

      // legacy we want to detect accidentally firing:
      .on('dmi:imageReadyForRender.dmiDebug', function (_e, payload) {
        warn('LEGACY EVENT dmi:imageReadyForRender fired (something old is emitting this!)', payload);
      });
  });

  // --- expose helpers
  NS.debug = { dump: debugDump, force, on: (e,fn)=>document.addEventListener(e,fn) };

  // initial banner
  info('DMI Debug loaded. Use DMI.debug.dump() and DMI.debug.force("artApproved"|"triggerRender").');
})();
