/*
 * File: assets/js/frontend.js
 * Description: Controls upload visibility for variations and handles approval of vectorized preview (popup-only; no inline vectorization)
 * Plugin: Dynamic Mockups Integration
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11 16:07 EDT
 */

document.addEventListener('DOMContentLoaded', function () {
  // Variation visibility logic
  const uploadContainer = document.getElementById('dmi-upload-container');
  const form = document.querySelector('form.variations_form');

  if (form && uploadContainer) {
    const selects = form.querySelectorAll('select');
    const checkVisibility = () => {
      let allSelected = true;
      selects.forEach(select => { if (!select.value) allSelected = false; });
      uploadContainer.style.display = allSelected ? 'block' : 'none';
    };
    uploadContainer.style.display = 'none';
    selects.forEach(select => select.addEventListener('change', checkVisibility));
    form.addEventListener('woocommerce_variation_has_changed', checkVisibility);
  }

  // Elements for approval block (shown after popup OK)
  const previewContainer = document.getElementById('dmi-approval-container');
  const previewImage     = document.getElementById('dmi-preview-image');
  const originalImage    = document.getElementById('dmi-original-image');
  const approvalCheckbox = document.getElementById('dmi-approval-check');
  const continueBtn      = document.getElementById('dmi-approval-continue');
  const cancelBtn        = document.getElementById('dmi-approval-cancel');

  // IMPORTANT: remove any inline upload/change handling here to avoid double prompts.
  // We ONLY listen for the event emitted by upload-handler.js after the popup OK.

  document.addEventListener('dmi:imageUploaded', function (ev) {
    const { simplifiedURL, originalDataURL, hexList } = ev.detail || {};
    if (!simplifiedURL) return;

    // Populate approval UI
    if (previewImage)  previewImage.src  = simplifiedURL;
    if (originalImage) originalImage.src = originalDataURL || '';

    // Color count + hexes (hidden inputs + visible swatches)
    const countEl = document.getElementById('dmi-color-count-display');
    const hiddenCount = document.getElementById('dmi_color_count');
    const hiddenHexes = document.getElementById('dmi_color_hexes');
    const swatchContainer = document.getElementById('dmi-color-swatches');

    if (countEl) countEl.textContent = Array.isArray(hexList) ? hexList.length : '';
    if (hiddenCount) hiddenCount.value = Array.isArray(hexList) ? hexList.length : '';
    if (hiddenHexes) hiddenHexes.value = Array.isArray(hexList) ? hexList.join(',') : '';

    if (swatchContainer) {
      swatchContainer.innerHTML = '';
      if (Array.isArray(hexList)) {
        hexList.forEach(hex => {
          const swatch = document.createElement('div');
          swatch.style.width = '20px';
          swatch.style.height = '20px';
          swatch.style.border = '1px solid #ccc';
          swatch.style.backgroundColor = hex;
          swatch.title = hex;
          swatchContainer.appendChild(swatch);
        });
      }
    }

    // Show approval block now (popup is already closed by OK button)
    if (previewContainer) {
      previewContainer.style.display = 'block';
    }
  }, { once: false });

  if (previewContainer && previewImage && approvalCheckbox && continueBtn && cancelBtn) {
    approvalCheckbox.addEventListener('change', () => {
      continueBtn.disabled = !approvalCheckbox.checked;
    });

    cancelBtn.addEventListener('click', () => {
      previewContainer.style.display = 'none';
      if (previewImage)  previewImage.src  = '';
      if (originalImage) originalImage.src = '';
      approvalCheckbox.checked = false;
      continueBtn.disabled = true;
    });

    continueBtn.addEventListener('click', function () {
      const mockupUUID = document.getElementById('dmi-mockup-uuid')?.value;
      const smartUUID  = document.getElementById('dmi-smartobject-uuid')?.value;
      const imageURL   = previewImage?.src;

      if (!mockupUUID || !smartUUID || !imageURL) {
        alert("Missing render data.");
        return;
      }

      const formData = new FormData();
      formData.append('action', 'dmi_render_image');
      formData.append('_ajax_nonce', dmi_ajax.nonce);
      formData.append('mockup_uuid', mockupUUID);
      formData.append('smart_objects[0][uuid]', smartUUID);
      formData.append('smart_objects[0][image_url]', imageURL);

      const overlay = document.getElementById('dmi-spinner-overlay');
      if (overlay) overlay.style.display = 'block';

      fetch(dmi_ajax.ajax_url, { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => {
          if (overlay) overlay.style.display = 'none';
          if (data.success && data.rendered_url) {
            const preview = document.getElementById('dmi-upload-preview');
            if (preview) preview.innerHTML = `<img src="${data.rendered_url}" alt="Mockup" style="max-width:100%;">`;
            previewContainer.style.display = 'none';
          } else {
            alert("Render failed.");
            console.error(data);
          }
        })
        .catch(err => {
          if (overlay) overlay.style.display = 'none';
          alert("Render error.");
          console.error(err);
        });
    });
  }
});
