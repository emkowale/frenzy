/*
 * File: assets/js/render-handler.js
 * Description: Store approved art, swap to attributes UI; render only when dmi:triggerRender fires
 * Last Updated: 2025-08-11
 */
(function () {
  const NS = (window.DMI = window.DMI || {});
  if (NS.__renderBound) return;
  NS.__renderBound = true;

  function swapUiForAttributes() {
    try {
      const cartBlock   = document.querySelector('.dmi-cart-block');
      const form        = document.querySelector('form.variations_form') || document.querySelector('form.cart');
      const variations  = form && form.querySelector('.variations');
      const inkColors   = cartBlock && cartBlock.querySelector('.dmi-ink-colors');
      const uploadBlock = cartBlock && cartBlock.querySelector('#dmi-upload-container');

      if (inkColors) inkColors.remove();
      if (uploadBlock) {
        if (variations) {
          uploadBlock.parentNode.insertBefore(variations, uploadBlock);
          const hdr = document.createElement('h4');
          hdr.textContent = 'Choose your options';
          hdr.style.margin = '10px 0';
          hdr.style.fontWeight = '600';
          variations.parentNode.insertBefore(hdr, variations);
        }
        uploadBlock.remove();
      }
      document.dispatchEvent(new CustomEvent('dmi:attributesPhaseReady'));
      console.log('🧼 DMI: Upload UI removed, attributes placed.');
    } catch (e) { console.warn('DMI: UI swap failed:', e); }
  }

  function sendToRender(payload) {
    if (!payload?.mockup_uuid || !payload.smart_objects?.[0]) {
      alert('Missing render data.'); return;
    }
    const so = payload.smart_objects[0];

    if (NS.__renderInFlight) return;
    NS.__renderInFlight = true;

    NS.spinner?.show?.('Sending to mockup…');
    setTimeout(() => NS.spinner?.update?.('Rendering mockup…'), 75);

    const fd = new FormData();
    fd.append('action', 'dmi_render_image');
    fd.append('_ajax_nonce', (window.dmi_ajax && dmi_ajax.nonce) || '');
    fd.append('mockup_uuid', payload.mockup_uuid);
    fd.append('smart_objects[0][uuid]', so.uuid);
    fd.append('smart_objects[0][image_url]', so.image_url);
    if (typeof payload.color_count === 'number') fd.append('color_count', String(payload.color_count));

    jQuery.ajax({
      url: (window.dmi_ajax && dmi_ajax.ajax_url) || '/wp-admin/admin-ajax.php',
      type: 'POST', data: fd, processData: false, contentType: false,
      success: function (resp) {
        NS.__renderInFlight = false; NS.spinner?.hide?.();
        if (!(resp && resp.success && resp.data && resp.data.rendered_url)) {
          console.error('DMI: Render failed:', resp); alert('× Render failed. Please try again.'); return;
        }
        const renderedURL = resp.data.rendered_url;
        const preview = document.getElementById('dmi-upload-preview');
        if (preview) {
          preview.style.display = 'block';
          preview.innerHTML = `<img src="${renderedURL}" alt="Mockup" style="max-width:100%;height:auto;display:block;border-radius:8px;">`;
        }
        document.dispatchEvent(new CustomEvent('dmi:renderComplete', { detail: { rendered_url: renderedURL } }));
        console.log('✅ DMI: Render complete.');
      },
      error: function (_x, _s, err) {
        NS.__renderInFlight = false; NS.spinner?.hide?.();
        console.error('DMI: Render AJAX error:', err); alert('× Render error. Please try again.');
      }
    });
  }

  jQuery(function ($) {
    // Approval → store payload and swap UI (do NOT render)
    $(document).off('dmi:artApproved.render')
      .on('dmi:artApproved.render', function (_e, payload) {
        NS.render = NS.render || {};
        NS.render.pendingPayload = payload;
        swapUiForAttributes();
      });

    // Explicit trigger from attributes-guard → now render
    $(document).off('dmi:triggerRender.render')
      .on('dmi:triggerRender.render', function () {
        if (!NS.render?.pendingPayload) { alert('Artwork not approved yet.'); return; }
        sendToRender(NS.render.pendingPayload);
      });
  });

  NS.render = NS.render || {};
  NS.render.sendToRender = sendToRender;
})();
