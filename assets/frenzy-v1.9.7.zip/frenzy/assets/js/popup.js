/*
 * File: assets/js/popup.js
 * Description: Optimization popup with preview, swatches, approval; emits dmi:artApproved
 * Last Updated: 2025-08-11
 */
(function () {
  const NS = (window.DMI = window.DMI || {});
  if (NS.__popupReady) return;
  NS.__popupReady = true;

  function openOptimizationPopup(originalDataURL, optimizedURL, hexList) {
    const swatches = (hexList || []).map(hex =>
      `<span style="display:inline-block;width:22px;height:22px;border-radius:4px;border:1px solid #ccc;background-color:${hex}" title="${hex}"></span>`
    ).join('<span style="width:8px;display:inline-block;"></span>');

    const modal = jQuery('<div class="dmi-alert-modal">').append(`
      <div class="dmi-alert-box">
        <style>
          .dmi-alert-modal{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:999998;display:flex;align-items:center;justify-content:center;padding:16px;}
          .dmi-alert-box{
            background:#fff;border-radius:16px;max-width:min(980px,96vw);width:100%;
            max-height:90vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.35);
            font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;padding:18px 20px 20px;
          }
          .dmi-hdr{display:flex;align-items:center;gap:10px;justify-content:center;margin:4px 0 10px;}
          .dmi-hdr img{height:26px}
          .dmi-title{font-size:18px;font-weight:700}
          .dmi-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
          @media (max-width: 800px){ .dmi-grid{grid-template-columns:1fr} }
          .dmi-panel{border:1px solid #dedede;border-radius:10px;padding:10px;}
          .dmi-panel h4{margin:0 0 8px 0;text-align:center}
          .dmi-panel img{max-width:100%;height:auto;display:block;margin:0 auto;border-radius:6px}
          .dmi-swatches{text-align:center;margin:10px 0 6px}
          .dmi-helper{text-align:center;color:#333;margin:0 0 10px 0;font-size:14px}
          .dmi-approve{display:flex;align-items:center;gap:8px;justify-content:center;margin:8px 0 12px}
          .dmi-actions{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
          .dmi-actions .button{background:#7e3e3a;color:#fff;border:none;border-radius:6px;padding:10px 14px;cursor:pointer}
          .dmi-actions .button[disabled]{opacity:.45;cursor:not-allowed}
          .dmi-actions .button.secondary{background:#b25752}
        </style>

        <div class="dmi-hdr">
          <img src="https://thebeartraxs.com/wp-content/uploads/2025/04/Bear-Traxs-Logo-favicon-70px-x-70px.png" alt="logo">
          <div class="dmi-title">Image Optimized</div>
        </div>

        <div class="dmi-grid">
          <div class="dmi-panel"><h4>Original</h4><img src="${originalDataURL}" alt="Original"></div>
          <div class="dmi-panel"><h4>Optimized</h4><img src="${optimizedURL}" class="dmi-optimized-img" alt="Optimized"></div>
        </div>

        <div class="dmi-swatches">${swatches}</div>
        <p class="dmi-helper">This helps reduce printing cost and ensure clean, high-quality output.</p>

        <label class="dmi-approve">
          <input id="dmi-approve-checkbox" type="checkbox">
          <span>By checking this box, I approve this design for printing.</span>
        </label>

        <div class="dmi-actions">
          <button id="dmi-approve-send" class="button" disabled>OK – SEND TO MOCKUP</button>
          <button id="dmi-approve-cancel" class="button secondary">CHANGE INK COLORS</button>
        </div>
      </div>
    `);

    jQuery('body').append(modal);

    const $send = modal.find('#dmi-approve-send');
    modal.find('#dmi-approve-checkbox').on('change', function () {
      $send.prop('disabled', !this.checked);
    });

    modal.find('#dmi-approve-cancel').on('click', function () { modal.remove(); });

    // Approve → emit *new* event (no auto-render)
    modal.find('#dmi-approve-send').on('click', function () {
      if ($send.prop('disabled')) return;

      const mockupUUID      = document.getElementById('dmi-mockup-uuid')?.value;
      const smartObjectUUID = document.getElementById('dmi-smartobject-uuid')?.value;
      const inkSelect       = document.getElementById('dmi-ink-color-count');
      const colorCount      = inkSelect ? parseInt(inkSelect.value || '2', 10) : 2;

      const payload = {
        mockup_uuid: mockupUUID,
        smart_objects: [{ uuid: smartObjectUUID, image_url: optimizedURL }],
        color_count: colorCount,
        hex_list: hexList || []
      };

      modal.remove();
      jQuery(document).trigger('dmi:artApproved', [payload]); // <-- new event
    });
  }

  NS.popup = { openOptimizationPopup };
})();
