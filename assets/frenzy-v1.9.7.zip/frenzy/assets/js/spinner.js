/*
 * File: assets/js/spinner.js
 * Description: Minimal modal spinner with status updates (framework-free)
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11
 */
(function () {
  const NS = (window.DMI = window.DMI || {});
  if (NS.__spinnerReady) return;
  NS.__spinnerReady = true;

  function show(message) {
    const existing = document.getElementById('dmi-spinner-modal');
    if (existing) {
      update(message);
      existing.style.display = 'block';
      return;
    }
    const html = `
    <div id="dmi-spinner-modal" aria-live="polite" aria-busy="true">
      <style>
        #dmi-spinner-modal { position: fixed; inset: 0; z-index: 999999; display: block; }
        #dmi-spinner-modal .dmi-spinner-backdrop { position: absolute; inset: 0; background: rgba(0,0,0,.45); }
        #dmi-spinner-modal .dmi-spinner-inner {
          position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
          background: #fff; border-radius: 14px; padding: 22px 26px; width: min(480px, 92vw);
          box-shadow: 0 10px 30px rgba(0,0,0,.25); text-align: center;
          font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
        }
        #dmi-spinner-modal .dmi-spinner-icon {
          width: 56px; height: 56px; display: inline-block; margin-bottom: 10px;
          border-radius: 50%; border: 5px solid #e9e9e9; border-top-color: #111;
          animation: dmi-spin 1s linear infinite;
        }
        #dmi-spinner-modal .dmi-spinner-message { margin-top: 8px; font-size: 15px; color: #222; }
        @keyframes dmi-spin { to { transform: rotate(360deg); } }
      </style>
      <div class="dmi-spinner-backdrop"></div>
      <div class="dmi-spinner-inner">
        <div class="dmi-spinner-icon" role="progressbar" aria-valuetext="Loading"></div>
        <div class="dmi-spinner-message">${message || 'Processing your image…'}</div>
      </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
  }

  function update(message) {
    const el = document.querySelector('#dmi-spinner-modal .dmi-spinner-message');
    if (el && message) el.textContent = message;
  }

  function hide() {
    const el = document.getElementById('dmi-spinner-modal');
    if (el) el.remove();
  }

  NS.spinner = { show, update, hide };
})();
