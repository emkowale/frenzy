/*
 * File: assets/js/attributes-guard.js
 * Description: After approval, require attribute selection + confirmation before allowing render
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11
 */

(function () {
  const NS = (window.DMI = window.DMI || {});
  if (NS.__attrsGuard) return;
  NS.__attrsGuard = true;

  function allAttributesSelected(root) {
    const selects = root.querySelectorAll('.variations select');
    if (!selects.length) return true; // simple products: nothing to choose
    for (const sel of selects) {
      if (!sel.value || sel.value === '') return false;
    }
    return true;
  }

  function ensureControls() {
    const form = document.querySelector('form.variations_form') || document.querySelector('form.cart');
    if (!form) return;

    // don’t duplicate
    if (form.querySelector('#dmi-attrs-confirm')) return;

    const container = document.createElement('div');
    container.className = 'dmi-attrs-confirm-wrap';
    container.style.marginTop = '12px';

    container.innerHTML = `
      <style>
        .dmi-attrs-confirm-wrap { display:flex; flex-direction:column; gap:10px; }
        #dmi-attrs-confirm-row { display:flex; align-items:center; gap:8px; }
        #dmi-render-btn {
          display:none; background:#7e3e3a; color:#fff; border:none; border-radius:6px;
          padding:10px 14px; cursor:not-allowed; opacity:.5; width:fit-content;
        }
        #dmi-render-btn.enabled { cursor:pointer; opacity:1; }
      </style>
      <div id="dmi-attrs-confirm-row">
        <input type="checkbox" id="dmi-attrs-confirm">
        <label for="dmi-attrs-confirm">These are the attributes I want</label>
      </div>
      <button type="button" id="dmi-render-btn">Render My Product</button>
    `;

    // place after variations or at end of form
    const variations = form.querySelector('.variations');
    if (variations?.parentNode) {
      variations.parentNode.insertBefore(container, variations.nextSibling);
    } else {
      form.appendChild(container);
    }

    const confirmCb = container.querySelector('#dmi-attrs-confirm');
    const renderBtn  = container.querySelector('#dmi-render-btn');

    function reevaluate() {
      const ready = allAttributesSelected(form) && confirmCb.checked;
      // button visible only once they start confirming/selecting
      renderBtn.style.display = (confirmCb.checked || allAttributesSelected(form)) ? 'inline-block' : 'none';
      renderBtn.classList.toggle('enabled', ready);
      renderBtn.disabled = !ready;
    }

    confirmCb.addEventListener('change', reevaluate);

    // watch attribute selects
    form.querySelectorAll('.variations select').forEach(sel => {
      sel.addEventListener('change', reevaluate);
    });

    // click → trigger render
    renderBtn.addEventListener('click', function () {
      if (!renderBtn.classList.contains('enabled')) return;
      document.dispatchEvent(new CustomEvent('dmi:triggerRender'));
    });

    // initial state
    reevaluate();
  }

  // Build controls when attributes UI is ready
  jQuery(function ($) {
    $(document).off('dmi:attributesPhaseReady.guard')
      .on('dmi:attributesPhaseReady.guard', function () {
        ensureControls();
        // scroll into view for user
        const el = document.querySelector('.dmi-attrs-confirm-wrap');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
  });
})();
