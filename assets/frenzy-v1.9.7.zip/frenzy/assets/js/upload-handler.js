/*
 * File: assets/js/upload-handler.js
 * Description: Python-only flow — upload file → server quantizes → popup shows original vs optimized with approval controls
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11
 */

(function () {
  if (window.DMI && window.DMI.__uploadBound) return;
  window.DMI = window.DMI || {};
  window.DMI.__uploadBound = true;

  // ---------- Spinner (robust, inline CSS, status updates) ----------
  function showSpinnerModal(message) {
    const existing = document.getElementById('dmi-spinner-modal');
    if (existing) {
      const msg = existing.querySelector('.dmi-spinner-message');
      if (msg && message) msg.textContent = message;
      existing.style.display = 'block';
      return;
    }
    const html = `
    <div id="dmi-spinner-modal" aria-live="polite" aria-busy="true">
      <style>
        #dmi-spinner-modal { position: fixed; inset: 0; z-index: 999999; display: block; }
        #dmi-spinner-modal .dmi-spinner-backdrop { position: absolute; inset: 0; background: rgba(0,0,0,.45); }
        #dmi-spinner-modal .dmi-spinner-inner {
          position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%);
          background: #fff; border-radius: 14px; padding: 22px 26px; width: min(480px, 92vw);
          box-shadow: 0 10px 30px rgba(0,0,0,.25); text-align: center;
          font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
        }
        #dmi-spinner-modal .dmi-spinner-icon {
          width: 56px; height: 56px; display: inline-block; margin-bottom: 10px;
          border-radius: 50%; border: 5px solid #e9e9e9; border-top-color: #111;
          animation: dmi-spin 1s linear infinite;
        }
        #dmi-spinner-modal .dmi-spinner-message { margin-top: 8px; font-size: 15px; color: #222; }
        @keyframes dmi-spin { to { transform: rotate(360deg); } }
      </style>
      <div class="dmi-spinner-backdrop"></div>
      <div class="dmi-spinner-inner">
        <div class="dmi-spinner-icon" role="progressbar" aria-valuetext="Loading"></div>
        <div class="dmi-spinner-message">${message || 'Processing your image…'}</div>
      </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
  }

  function updateSpinnerMessage(message) {
    const el = document.querySelector('#dmi-spinner-modal .dmi-spinner-message');
    if (el && message) el.textContent = message;
  }

  function hideSpinnerModal() {
    const el = document.getElementById('dmi-spinner-modal');
    if (el) el.remove();
  }

  // ---------- Popup (with approval + send/cancel) ----------
  function openPopup(originalDataURL, optimizedURL, hexList) {
    const swatches = (hexList || []).map(hex =>
      `<span style="display:inline-block;width:22px;height:22px;border-radius:4px;border:1px solid #ccc;background-color:${hex}" title="${hex}"></span>`
    ).join('<span style="width:8px;display:inline-block;"></span>');

    const modal = jQuery('<div class="dmi-alert-modal">').append(`
      <div class="dmi-alert-box">
        <style>
          .dmi-alert-modal{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:999998;display:flex;align-items:center;justify-content:center;padding:16px;}
          .dmi-alert-box{
            background:#fff;border-radius:16px;max-width:min(980px,96vw);width:100%;
            max-height:90vh;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.35);
            font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;padding:18px 20px 20px;
          }
          .dmi-hdr{display:flex;align-items:center;gap:10px;justify-content:center;margin:4px 0 10px;}
          .dmi-hdr img{height:26px}
          .dmi-title{font-size:18px;font-weight:700}
          .dmi-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
          @media (max-width: 800px){ .dmi-grid{grid-template-columns:1fr} }
          .dmi-panel{border:1px solid #dedede;border-radius:10px;padding:10px;}
          .dmi-panel h4{margin:0 0 8px 0;text-align:center}
          .dmi-panel img{max-width:100%;height:auto;display:block;margin:0 auto;border-radius:6px}
          .dmi-swatches{text-align:center;margin:10px 0 6px}
          .dmi-helper{text-align:center;color:#333;margin:0 0 10px 0;font-size:14px}
          .dmi-approve{display:flex;align-items:center;gap:8px;justify-content:center;margin:8px 0 12px}
          .dmi-actions{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
          .dmi-actions .button{background:#7e3e3a;color:#fff;border:none;border-radius:6px;padding:10px 14px;cursor:pointer}
          .dmi-actions .button[disabled]{opacity:.45;cursor:not-allowed}
          .dmi-actions .button.secondary{background:#b25752}
        </style>

        <div class="dmi-hdr">
          <img src="https://thebeartraxs.com/wp-content/uploads/2025/04/Bear-Traxs-Logo-favicon-70px-x-70px.png" alt="logo">
          <div class="dmi-title">Image Optimized</div>
        </div>

        <div class="dmi-grid">
          <div class="dmi-panel">
            <h4>Original</h4>
            <img src="${originalDataURL}" alt="Original">
          </div>
          <div class="dmi-panel">
            <h4>Optimized</h4>
            <img src="${optimizedURL}" class="dmi-optimized-img" alt="Optimized">
          </div>
        </div>

        <div class="dmi-swatches">${swatches}</div>
        <p class="dmi-helper">This helps reduce printing cost and ensure clean, high-quality output.</p>

        <label class="dmi-approve">
          <input id="dmi-approve-checkbox" type="checkbox">
          <span>By checking this box, I approve this design for printing.</span>
        </label>

        <div class="dmi-actions">
          <button id="dmi-approve-send" class="button" disabled>OK – SEND TO MOCKUP</button>
          <button id="dmi-approve-cancel" class="button secondary">CHANGE INK COLORS</button>
        </div>
      </div>
    `);

    jQuery('body').append(modal);

    // Enable/disable Send
    const $send = modal.find('#dmi-approve-send');
    modal.find('#dmi-approve-checkbox').on('change', function () {
      $send.prop('disabled', !this.checked);
    });

    // Change Ink Colors just closes
    modal.find('#dmi-approve-cancel').on('click', function () {
      modal.remove();
    });

    // Send to mockup directly from popup
    modal.find('#dmi-approve-send').on('click', function () {
      if ($send.prop('disabled')) return;

      const mockupUUID      = document.getElementById('dmi-mockup-uuid')?.value;
      const smartObjectUUID = document.getElementById('dmi-smartobject-uuid')?.value;
      const inkSelect       = document.getElementById('dmi-ink-color-count');
      const colorCount      = inkSelect ? parseInt(inkSelect.value || '2', 10) : 2;

      if (!mockupUUID || !smartObjectUUID || !optimizedURL) {
        alert('Missing mockup data or image.');
        return;
      }

      modal.remove();
      jQuery(document).trigger('dmi:imageReadyForRender', [{
        mockup_uuid: mockupUUID,
        smart_objects: [{ uuid: smartObjectUUID, image_url: optimizedURL }],
        color_count: colorCount
      }]);
    });
  }

  // ---------- Bindings ----------
  jQuery(function ($) {
    // Button → open file dialog (single owner)
    $(document).off('click.dmiUpload', '#dmi-upload-button')
      .on('click.dmiUpload', '#dmi-upload-button', function (e) {
        e.preventDefault(); e.stopPropagation();
        if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
        const input = document.getElementById('dmi-upload');
        if (input) input.click();
      });

    // File selected → send to Python vectorizer (spinner shows immediately)
    $(document).off('change.dmiUpload', '#dmi-upload')
      .on('change.dmiUpload', '#dmi-upload', function () {
        const file = this.files && this.files[0];
        if (!file) return;

        // Show spinner right away
        showSpinnerModal('Reading file…');

        const reader = new FileReader();
        reader.onload = function (ev) {
          const originalDataURL = ev.target.result;

          const formData = new FormData();
          formData.append('action', 'dmi_vectorize_upload');
          formData.append('_ajax_nonce', (window.dmi_ajax && dmi_ajax.nonce) || '');
          formData.append('image', file);

          const inkSelect = document.getElementById('dmi-ink-color-count');
          if (inkSelect) formData.append('ink_colors', inkSelect.value || 2);

          // Optional: enable glow removal by sending a threshold (e.g., 35)
          // formData.append('bg_thresh', 35);

          updateSpinnerMessage('Uploading…');

          jQuery.ajax({
            url: (window.dmi_ajax && dmi_ajax.ajax_url) || '/wp-admin/admin-ajax.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function () {
              const xhr = jQuery.ajaxSettings.xhr();
              if (xhr && xhr.upload) {
                xhr.upload.addEventListener('progress', function (e) {
                  if (e.lengthComputable) {
                    const pct = Math.round((e.loaded / e.total) * 100);
                    updateSpinnerMessage(`Uploading… ${pct}%`);
                  }
                });
              }
              return xhr;
            },
            beforeSend: function () {
              setTimeout(() => updateSpinnerMessage('Optimizing (no dithering)…'), 50);
            },
            success: function (resp) {
              if (resp && resp.success && resp.data && resp.data.preview_url) {
                const optURL = resp.data.preview_url;
                const hexes  = resp.data.color_hexes || [];
                setTimeout(() => {
                  hideSpinnerModal();
                  openPopup(originalDataURL, optURL, hexes);
                }, 100);
              } else {
                console.error('Vectorize error:', resp);
                hideSpinnerModal();
                alert('× Error vectorizing image.');
              }
            },
            error: function (_x, _s, err) {
              console.error('Vectorize AJAX error:', err);
              hideSpinnerModal();
              alert('× Error vectorizing image.');
            }
          });
        };

        reader.readAsDataURL(file);
        // allow selecting the same file again later
        this.value = '';
      });
  });
})();
