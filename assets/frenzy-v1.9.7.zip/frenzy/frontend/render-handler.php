<?php
// Handles image rendering via AJAX
