#!/usr/bin/env python3
# Exact-K color quantization for screen printing (no dithering), Pillow-only (no NumPy)
# Prints JSON: {"ok": true, "out": "...", "colors": ["#RRGGBB", ...]}

import argparse, json, sys
from PIL import Image, ImageFilter

def hexrgb(rgb): return "#{:02x}{:02x}{:02x}".format(*rgb)

# --- Pillow compatibility shims ---
# Dither flag
try:
    DITHER_NONE = Image.Dither.NONE         # newer Pillow
except AttributeError:
    DITHER_NONE = getattr(Image, "NONE", 0) # older Pillow: constant or 0

# Quantize method
try:
    METHOD_MEDIANCUT = Image.MEDIANCUT      # newer Pillow
except AttributeError:
    METHOD_MEDIANCUT = 0                    # older Pillow uses ints

def remove_dark_bg(img_rgba, thresh):
    """Make near-black background transparent via luminance threshold. thresh < 0 keeps background."""
    if thresh < 0:
        return img_rgba
    # Luma channel (0..255)
    luma = img_rgba.convert("L")
    r, g, b, a = img_rgba.split()
    # Build keep mask: 255 where luma >= thresh, else 0
    keep = luma.point(lambda v: 255 if v >= thresh else 0, mode="L")
    # New alpha = min(original alpha, keep)
    new_a = Image.composite(a, Image.new("L", a.size, 0), Image.eval(keep, lambda px: 255 - px))
    return Image.merge("RGBA", (r, g, b, new_a))

def quantize_exact_k(img_rgba, k):
    """Quantize to exactly K colors (no dithering). Returns (RGBA image, [hex colors])."""
    # Gentle denoise to avoid speckle colors
    denoised = img_rgba.filter(ImageFilter.MedianFilter(size=3))
    # Quantize RGB → indexed palette image
    q = denoised.convert("RGB").quantize(
        colors=max(1, min(256, int(k))),
        method=METHOD_MEDIANCUT,
        dither=DITHER_NONE
    )
    # Back to RGB, restore alpha
    rgb_q = q.convert("RGB")
    out = rgb_q.copy()
    out.putalpha(denoised.split()[3])

    # Palette extraction: use only indices actually present
    used_counts = q.getcolors(maxcolors=256) or []  # [(count, index), ...]
    used_indices = [idx for cnt, idx in used_counts]
    pal = q.getpalette() or []
    colors = []
    for idx in used_indices:
        base = 3 * int(idx)
        if base + 2 < len(pal):
            colors.append((int(pal[base]), int(pal[base+1]), int(pal[base+2])))
    palette_hex = [hexrgb(c) for c in colors]
    return out, palette_hex

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--inp", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--k", type=int, required=True)
    p.add_argument("--bg-thresh", type=int, default=-1)  # -1 keep background
    args = p.parse_args()

    try:
        img = Image.open(args.inp).convert("RGBA")
        img = remove_dark_bg(img, args.bg_thresh)
        out_img, palette_hex = quantize_exact_k(img, args.k)
        out_img.save(args.out)
        print(json.dumps({"ok": True, "out": args.out, "colors": palette_hex}))
        return 0
    except Exception as e:
        print(json.dumps({"ok": False, "err": str(e)}))
        return 1

if __name__ == "__main__":
    sys.exit(main())
