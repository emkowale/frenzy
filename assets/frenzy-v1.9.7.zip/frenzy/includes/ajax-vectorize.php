<?php
/*
 * File: includes/ajax-vectorize.php
 * Description: Uses Python (Pillow) to quantize uploads to K colors (no dithering), returns preview URL + palette
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_dmi_vectorize_upload', 'dmi_handle_vectorize_upload');
add_action('wp_ajax_nopriv_dmi_vectorize_upload', 'dmi_handle_vectorize_upload');

function dmi_handle_vectorize_upload() {
    $nonce = $_POST['_ajax_nonce'] ?? '';
    if (!wp_verify_nonce($nonce, 'dmi_nonce')) {
        wp_send_json_error(['message' => 'Security check failed']);
    }

    if (empty($_FILES['image']) || empty($_FILES['image']['tmp_name'])) {
        wp_send_json_error(['message' => 'No image received']);
    }

    $file = $_FILES['image'];
    $allowed = ['image/jpeg','image/png'];
    if (!in_array($file['type'], $allowed, true)) {
        wp_send_json_error(['message' => 'Invalid file type']);
    }

    $u = wp_upload_dir();
    $dir = trailingslashit($u['basedir']).'dmi-temp/';
    $url = trailingslashit($u['baseurl']).'dmi-temp/';
    if (!is_dir($dir) && !wp_mkdir_p($dir)) {
        wp_send_json_error(['message' => 'Failed to create temp directory']);
    }

    $name = wp_unique_filename($dir, $file['name']);
    $in_path = $dir.$name;
    if (!move_uploaded_file($file['tmp_name'], $in_path)) {
        wp_send_json_error(['message' => 'Failed to save file']);
    }

    $k = isset($_POST['ink_colors']) ? (int)$_POST['ink_colors'] : 2;
    if ($k < 1) $k = 1; if ($k > 6) $k = 6;

    $bg_thresh = isset($_POST['bg_thresh']) ? (int)$_POST['bg_thresh'] : -1; // -1 = keep background

    $out_path = $dir.pathinfo($name, PATHINFO_FILENAME)."_k{$k}.png";

    // Adjust if python is elsewhere (e.g., /usr/local/bin/python3)
    $python = 'python3';
    $script = plugin_dir_path(__FILE__).'../scripts/dmi_quantize.py';

    $cmd = escapeshellcmd($python).' '.
           escapeshellarg($script).' '.
           '--inp '.escapeshellarg($in_path).' '.
           '--out '.escapeshellarg($out_path).' '.
           '--k '.escapeshellarg($k).' '.
           '--bg-thresh '.escapeshellarg($bg_thresh);

    $output = [];
    $code = 0;
    @exec($cmd.' 2>&1', $output, $code);
    $joined = implode("\n", $output);
    $decoded = json_decode($joined, true);

    if (!$decoded || empty($decoded['ok']) || !file_exists($out_path)) {
        wp_send_json_error(['message' => 'Vectorization failed', 'debug' => $joined]);
    }

    $preview_url = $url.basename($out_path);
    $hexes = is_array($decoded['colors'] ?? null) ? array_values($decoded['colors']) : [];

    wp_send_json_success([
        'preview_url' => esc_url_raw($preview_url),
        'color_count' => count($hexes),
        'color_hexes' => $hexes
    ]);
}
