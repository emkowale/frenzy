<?php
/*
 * File: includes/enqueue-scripts.php
 * Description: Enqueues modular frontend JS/CSS for Dynamic Mockups Integration
 * Plugin: Dynamic Mockups Integration
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11 21:10 EDT
 */

if (!defined('ABSPATH')) exit;

function dmi_enqueue_modular_scripts() {
    $base_dir = plugin_dir_path(__DIR__);
    $base_url = plugin_dir_url(__DIR__);

    // Helper for cache-busting based on file mtime
    $ver = function($relPath) use ($base_dir) {
        $abs = $base_dir . ltrim($relPath, '/');
        return file_exists($abs) ? filemtime($abs) : '1.0';
    };

    // CSS on product, cart, and checkout
    if (is_product() || is_cart() || is_checkout()) {
        wp_enqueue_style(
            'dmi-frontend-style',
            $base_url . 'assets/css/frontend.css',
            [],
            $ver('assets/css/frontend.css')
        );
    }

    // JS only on single product
    if (is_product()) {
        // Base UI init (no handlers inside)
        wp_enqueue_script(
            'dmi-ui-init',
            $base_url . 'assets/js/ui-init.js',
            ['jquery'],
            $ver('assets/js/ui-init.js'),
            true
        );

        // New modular stack (order matters)
        wp_enqueue_script(
            'dmi-spinner',
            $base_url . 'assets/js/spinner.js',
            ['jquery'],
            $ver('assets/js/spinner.js'),
            true
        );
        wp_enqueue_script(
            'dmi-popup',
            $base_url . 'assets/js/popup.js',
            ['jquery', 'dmi-spinner'],
            $ver('assets/js/popup.js'),
            true
        );
        wp_enqueue_script(
            'dmi-uploader',
            $base_url . 'assets/js/uploader.js',
            ['jquery', 'dmi-popup'],
            $ver('assets/js/uploader.js'),
            true
        );

        // Render step (uses spinner too for consistent UX)
        wp_enqueue_script(
            'dmi-render-handler',
            $base_url . 'assets/js/render-handler.js',
            ['jquery', 'dmi-spinner'],
            $ver('assets/js/render-handler.js'),
            true
        );

        wp_enqueue_script(
            'dmi-attributes-guard',
            $base_url . 'assets/js/attributes-guard.js',
            ['jquery', 'dmi-render-handler'],
            $ver('assets/js/attributes-guard.js'),
            true
        );

        // Other modules still in use
        wp_enqueue_script(
            'dmi-zoom',
            $base_url . 'assets/js/zoom.js',
            ['jquery'],
            $ver('assets/js/zoom.js'),
            true
        );
        wp_enqueue_script(
            'dmi-confirm-overlay',
            $base_url . 'assets/js/confirm-overlay.js',
            ['jquery'],
            $ver('assets/js/confirm-overlay.js'),
            true
        );
        wp_enqueue_script(
            'dmi-form-guard',
            $base_url . 'assets/js/form-guard.js',
            ['jquery'],
            $ver('assets/js/form-guard.js'),
            true
        );

        // Localize only what needs AJAX
        $localized_data = [
            'ajax_url'   => admin_url('admin-ajax.php'),
            'nonce'      => wp_create_nonce('dmi_nonce'),
            'product_id' => get_the_ID(),
        ];
        wp_localize_script('dmi-ui-init',        'dmi_ajax', $localized_data);
        wp_localize_script('dmi-uploader',       'dmi_ajax', $localized_data);
        wp_localize_script('dmi-render-handler', 'dmi_ajax', $localized_data);
    }
}
add_action('wp_enqueue_scripts', 'dmi_enqueue_modular_scripts');

// Debug helper (load only with ?dmi_debug=1)
if (is_product() && isset($_GET['dmi_debug']) && $_GET['dmi_debug'] === '1') {
    wp_enqueue_script(
        'dmi-debug',
        $base_url . 'assets/js/dmi-debug.js',
        ['jquery'],
        $ver('assets/js/dmi-debug.js'),
        true
    );
}
