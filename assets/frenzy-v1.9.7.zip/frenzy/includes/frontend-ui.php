<?php
/*
 * File: includes/frontend-ui.php
 * Description: Frontend UI markup for image upload and Dynamic Mockups rendering (popup-only approval)
 * Plugin: Dynamic Mockups Integration
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11
 */

if (!defined('ABSPATH')) exit;

// Enqueue base CSS (JS enqueued via includes/enqueue-scripts.php)
add_action('wp_enqueue_scripts', function () {
    if (!is_singular('product')) return;

    wp_enqueue_style(
        'dmi-frontend-style',
        plugin_dir_url(__FILE__) . '../assets/css/frontend.css',
        array(),
        '1.9.6'
    );
});

// Insert UI near add-to-cart
add_action('woocommerce_before_add_to_cart_button', 'dmi_render_upload_ui');
// Fallback if theme doesn’t use the above hook
add_action('woocommerce_single_product_summary', 'dmi_render_upload_ui_fallback', 25);

function dmi_render_upload_ui() {
    dmi_output_upload_block('primary');
}

function dmi_render_upload_ui_fallback() {
    if (did_action('woocommerce_before_add_to_cart_button') > 0) return;
    dmi_output_upload_block('fallback');
}

function dmi_output_upload_block($context = 'primary') {
    global $product;

    if (!is_singular('product') || !$product || !is_a($product, 'WC_Product')) return;

    $mockup_uuid     = get_post_meta($product->get_id(), '_dmi_mockup_uuid', true);
    $smartobject_uuid= get_post_meta($product->get_id(), '_dmi_smartobject_uuid', true);
    $is_manufactured = get_post_meta($product->get_id(), '_dmi_manufactured_at_cnc', true) === 'yes';

    echo "<!-- DMI DEBUG [$context]: mockup_uuid = " . esc_html($mockup_uuid) . " | smartobject_uuid = " . esc_html($smartobject_uuid) . " -->";

    if (!$mockup_uuid || !$smartobject_uuid) return;

    $type_class = $product->is_type('variable') ? 'dmi-variable' : 'dmi-simple';

    echo '<div class="dmi-cart-block ' . esc_attr($type_class) . '">';

    // Ink Colors Dropdown (only if flagged for C&C)
    if ($is_manufactured) {
        echo '<div class="dmi-ink-colors" style="margin-bottom: 15px;">';
        echo '<label for="dmi-ink-color-count" style="font-weight: 600;">Select Number of Ink Colors:</label><br>';
        echo '<select id="dmi-ink-color-count" name="dmi_ink_color_count" style="margin-top: 5px; padding: 4px; max-width: 120px;">';
        for ($i = 1; $i <= 6; $i++) {
            echo "<option value=\"$i\">$i Color" . ($i > 1 ? 's' : '') . "</option>";
        }
        echo '</select>';
        echo '</div>';
    }

    // Upload container (popup handles preview/approval)
    echo '<div id="dmi-upload-container">';
    echo '<input type="file" id="dmi-upload" accept="image/png, image/jpeg" style="display:none;">';
    echo '<button type="button" id="dmi-upload-button" class="button alt dmi-upload-button">Upload your own image</button>';
    echo '<div id="dmi-upload-preview" style="display:none;"></div>'; // kept for compatibility; not used
    echo '</div>';

    // Spinner overlay for the final render step (if your render-handler uses it)
    echo '<div id="dmi-spinner-overlay" style="display:none;"><div class="dmi-spinner"></div></div>';

    // Hidden data used by JS
    echo '<input type="hidden" id="dmi-mockup-uuid" value="' . esc_attr($mockup_uuid) . '">';
    echo '<input type="hidden" id="dmi-smartobject-uuid" value="' . esc_attr($smartobject_uuid) . '">';
    echo '<input type="hidden" id="dmi_color_count" name="dmi_color_count" value="">';
    echo '<input type="hidden" id="dmi_color_hexes" name="dmi_color_hexes" value="">';

    echo '</div>';
}
