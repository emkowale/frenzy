<?php
/*
 * File: includes/upload-handler.php
 * Description: Handles AJAX image uploads for Dynamic Mockups (returns {success:true, data:{url,...}})
 * Plugin: Dynamic Mockups Integration
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11 17:12 EDT
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_dmi_upload_image', 'dmi_handle_image_upload');
add_action('wp_ajax_nopriv_dmi_upload_image', 'dmi_handle_image_upload');

function dmi_handle_image_upload() {
    // Nonce
    $nonce = isset($_POST['_ajax_nonce']) ? $_POST['_ajax_nonce'] : '';
    if (!wp_verify_nonce($nonce, 'dmi_nonce')) {
        wp_send_json_error(['message' => 'Security check failed.']);
    }

    // File presence
    if (empty($_FILES['file']) || empty($_FILES['file']['tmp_name'])) {
        wp_send_json_error(['message' => 'No file received.']);
    }

    $file = $_FILES['file'];

    // Type check
    $allowed_types = array('image/png', 'image/jpeg');
    if (!in_array($file['type'], $allowed_types, true)) {
        wp_send_json_error(['message' => 'Invalid file type. Only PNG and JPG are allowed.']);
    }

    // Prepare upload dir
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $upload_dir = wp_upload_dir();
    $target_dir = trailingslashit($upload_dir['basedir']) . 'dmi-temp/';
    $target_url = trailingslashit($upload_dir['baseurl']) . 'dmi-temp/';

    if (!is_dir($target_dir) && !wp_mkdir_p($target_dir)) {
        wp_send_json_error(['message' => 'Failed to create temp directory.']);
    }

    // Save file
    $filename    = wp_unique_filename($target_dir, $file['name']);
    $destination = $target_dir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        wp_send_json_error(['message' => 'Upload failed.']);
    }

    $public_url = $target_url . $filename;

    // Return in the { data: { url } } shape
    wp_send_json_success([
        'data' => [
            'url'      => esc_url_raw($public_url),
            'filename' => $filename,
        ],
    ]);
}
