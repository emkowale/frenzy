<?php
/*
 * File: includes/ajax-render.php
 * Description: Uses smart_objects array from frontend, enforces exact-K color quantization, then renders via Dynamic Mockups API using asset.url format
 * Plugin: Dynamic Mockups Integration
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-11 16:12 EDT
 */

if (!defined('ABSPATH')) exit;

add_action('wp_ajax_dmi_render_image', 'dmi_handle_render_request');
add_action('wp_ajax_nopriv_dmi_render_image', 'dmi_handle_render_request');

function dmi_handle_render_request() {
    $debug = [];

    $nonce = $_POST['_ajax_nonce'] ?? '';
    $debug['received_nonce'] = $nonce;
    if (!wp_verify_nonce($nonce, 'dmi_nonce')) {
        wp_send_json_error([
            'message' => 'Security check failed',
            'debug' => $debug
        ]);
    }

    $mockup_uuid   = sanitize_text_field($_POST['mockup_uuid'] ?? '');
    $smart_objects = $_POST['smart_objects'] ?? [];
    $ink_colors    = isset($_POST['ink_colors']) ? (int) $_POST['ink_colors'] : 0;
    if ($ink_colors < 1) $ink_colors = 1;
    if ($ink_colors > 6) $ink_colors = 6;

    $debug['mockup_uuid'] = $mockup_uuid;
    $debug['smart_objects'] = $smart_objects;
    $debug['ink_colors'] = $ink_colors;

    if (!$mockup_uuid || !is_array($smart_objects) || count($smart_objects) === 0) {
        wp_send_json_error([
            'message' => 'Missing parameters',
            'debug' => $debug
        ]);
    }

    $smart_object  = $smart_objects[0];
    $uuid          = sanitize_text_field($smart_object['uuid'] ?? '');
    $image_url_raw = esc_url_raw($smart_object['image_url'] ?? '');
    $image_url     = $image_url_raw . (strpos($image_url_raw, '?') === false ? '?' : '&') . 'nocache=' . time();

    $debug['smart_object_uuid'] = $uuid;
    $debug['image_url'] = $image_url;

    if (!$uuid || !$image_url_raw) {
        wp_send_json_error([
            'message' => 'Invalid smart object payload',
            'debug' => $debug
        ]);
    }

    global $post;
    $product_id = $post ? $post->ID : 0;
    $debug['product_id'] = $product_id;

    $top    = get_post_meta($product_id, '_dmi_smartobject_position_top', true);
    $left   = get_post_meta($product_id, '_dmi_smartobject_position_left', true);
    $width  = get_post_meta($product_id, '_dmi_smartobject_size_width', true);
    $height = get_post_meta($product_id, '_dmi_smartobject_size_height', true);

    $has_all_dimensions = ($top !== '' && $left !== '' && $width !== '' && $height !== '');
    $debug['position_meta_found'] = $has_all_dimensions;
    if ($has_all_dimensions) {
        $debug['position'] = ['top' => (int)$top, 'left' => (int)$left];
        $debug['size']     = ['width' => (int)$width, 'height' => (int)$height];
    }

    $api_key = get_option('dmi_api_key');
    $debug['api_key_present'] = $api_key ? true : false;
    if (!$api_key) {
        wp_send_json_error([
            'message' => 'Missing API key',
            'debug' => $debug
        ]);
    }

    // ---- NEW: Download & Quantize to EXACT K colors ----
    $optimized_url = '';
    $optimized_colors = [];
    $quantize_note = '';

    // 1) Download the user image to uploads/dmi-temp
    $download = dmi_download_to_temp($image_url_raw);
    if (!$download['ok']) {
        // Hard fail: we need a local file to quantize
        wp_send_json_error([
            'message' => 'Failed to fetch uploaded image for processing',
            'debug'   => array_merge($debug, ['download_error' => $download['err']])
        ]);
    }

    $local_src_path = $download['path'];

    // 2) Quantize using helper (user said color-quantize.php is included in main plugin file)
    if (function_exists('dmi_quantize_exact_gd')) {
        $q = dmi_quantize_exact_gd($local_src_path, $ink_colors, null, 0, 0);
        if (!empty($q['ok'])) {
            $optimized_path   = $q['out'];
            $optimized_colors = is_array($q['colors']) ? array_values($q['colors']) : [];
            $optimized_url    = dmi_file_url_from_path($optimized_path);
            $quantize_note    = 'quantized';
        } else {
            // Fallback to original download if quantization failed (still proceed to render)
            $optimized_path = $local_src_path;
            $optimized_url  = dmi_file_url_from_path($optimized_path);
            $quantize_note  = 'quantize_failed_fallback_original';
            $debug['quantize_error'] = $q['err'] ?? 'unknown';
        }
    } else {
        // Safety: if helper not loaded for some reason, proceed with the original
        $optimized_path = $local_src_path;
        $optimized_url  = dmi_file_url_from_path($optimized_path);
        $quantize_note  = 'quantize_helper_missing_fallback_original';
    }

    if (!$optimized_url) {
        wp_send_json_error([
            'message' => 'Could not publish optimized image URL',
            'debug'   => array_merge($debug, [
                'local_src_path' => $local_src_path,
                'optimized_path' => $optimized_path ?? null,
                'quantize_note'  => $quantize_note
            ])
        ]);
    }

    $debug['optimized_url']    = $optimized_url;
    $debug['optimized_colors'] = $optimized_colors;
    $debug['quantize_note']    = $quantize_note;

    // 3) Build smart object payload using the optimized URL
    $smart_obj_payload = [
        'uuid'  => $uuid,
        'asset' => [ 'url' => $optimized_url ],
    ];

    if ($has_all_dimensions) {
        $smart_obj_payload['position'] = [
            'top'  => (int)$top,
            'left' => (int)$left
        ];
        $smart_obj_payload['size'] = [
            'width'  => (int)$width,
            'height' => (int)$height
        ];
    }

    // ---- Call Dynamic Mockups API (unchanged) ----
    $url = 'https://app.dynamicmockups.com/api/v1/renders';
    $payload_array = [
        'mockup_uuid'     => $mockup_uuid,
        'smart_objects'   => [ $smart_obj_payload ],
        'output_format'   => 'jpeg',
        'flatten_layers'  => true
    ];
    $payload = json_encode($payload_array);

    $headers = [
        'x-api-key: ' . $api_key,
        'Content-Type: application/json',
        'Accept: application/json'
    ];

    $debug['request_url'] = $url;
    $debug['request_payload'] = $payload_array;

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response   = curl_exec($ch);
    $curl_error = curl_error($ch);
    $http_code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $decoded = json_decode($response, true);

    // Persist debug
    @file_put_contents(WP_CONTENT_DIR . '/dmi_render_debug.json', json_encode($decoded, JSON_PRETTY_PRINT));

    $debug['http_code']        = $http_code;
    $debug['curl_error']       = $curl_error;
    $debug['raw_response']     = $response;
    $debug['decoded_response'] = $decoded;

    if (
        !$decoded ||
        !isset($decoded['success']) ||
        $decoded['success'] !== true ||
        !isset($decoded['data']['export_path'])
    ) {
        wp_send_json_error([
            'message' => 'Render failed',
            'debug' => $debug
        ]);
    }

    if (isset($decoded['data']['warnings'])) {
        $debug['warnings'] = $decoded['data']['warnings'];
    }

    dmi_cleanup_old_temp_files(30);

    wp_send_json_success([
        'rendered_url' => esc_url_raw($decoded['data']['export_path']),
        'swatches'     => $optimized_colors, // expose exact palette used
        'debug'        => $debug
    ]);
}

/**
 * Download a remote image to uploads/dmi-temp and return local path.
 * @return array ['ok'=>bool, 'path'=>string, 'err'=>string]
 */
function dmi_download_to_temp(string $url): array {
    $upload_dir = wp_upload_dir();
    $temp_dir   = trailingslashit($upload_dir['basedir']) . 'dmi-temp/';

    if (!is_dir($temp_dir)) {
        if (!wp_mkdir_p($temp_dir)) {
            return ['ok'=>false, 'path'=>'', 'err'=>'Failed to create temp dir'];
        }
    }

    // Derive extension from URL; fallback to png
    $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH) ?? '', PATHINFO_EXTENSION));
    if (!in_array($ext, ['png','jpg','jpeg'])) {
        $ext = 'png';
    }

    $dest = $temp_dir . 'dmi_' . uniqid('', true) . '.' . $ext;

    // Fetch via cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $data = curl_exec($ch);
    $err  = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($data === false || $code >= 400) {
        return ['ok'=>false, 'path'=>'', 'err'=>$err ?: ('HTTP ' . $code)];
    }

    if (file_put_contents($dest, $data) === false) {
        return ['ok'=>false, 'path'=>'', 'err'=>'Failed to write file'];
    }

    return ['ok'=>true, 'path'=>$dest, 'err'=>''];
}

/**
 * Convert a local uploads path to a public URL.
 */
function dmi_file_url_from_path(string $path): string {
    $upload_dir = wp_upload_dir();
    $basedir = rtrim($upload_dir['basedir'], '/');
    $baseurl = rtrim($upload_dir['baseurl'], '/');

    if (strpos($path, $basedir) === 0) {
        return $baseurl . substr($path, strlen($basedir));
    }
    return '';
}

function dmi_cleanup_old_temp_files($days = 30) {
    $upload_dir = wp_upload_dir();
    $temp_dir = trailingslashit($upload_dir['basedir']) . 'dmi-temp/';

    if (!is_dir($temp_dir)) return;

    $files = glob($temp_dir . '*');
    $now = time();
    $cutoff = $now - ($days * 86400);

    foreach ($files as $file) {
        if (is_file($file) && filemtime($file) < $cutoff) {
            @unlink($file);
        }
    }
}
