<?php
/*
 * File: includes/product-meta-box.php
 * Description: Adds plain text fields for mockup UUID and smart object UUID with admin tooltips + C&C checkbox
 * Plugin: Dynamic Mockups Integration
 * Author: Eric Kowalewski
 * Last Updated: 2025-08-06 00:06 EDT
 */

if (!defined('ABSPATH')) exit;

add_action('woocommerce_product_options_general_product_data', function() {
    global $post;

    $selected_mockup = get_post_meta($post->ID, '_dmi_mockup_uuid', true);
    $selected_smart_object = get_post_meta($post->ID, '_dmi_smartobject_uuid', true);
    $manufactured_at_cnc = get_post_meta($post->ID, '_dmi_manufactured_at_cnc', true);

    // 🆕 C&C checkbox
    echo '<div class="options_group">';
    woocommerce_wp_checkbox(array(
        'id' => '_dmi_manufactured_at_cnc',
        'label' => 'Manufactured at C & C',
        'description' => 'Enable this if the product will be screen printed at C & C.',
        'value' => $manufactured_at_cnc === 'yes' ? 'yes' : 'no'
    ));
    echo '</div>';

    // ✅ Mockup UUID
    echo '<div class="options_group">';
    echo '<p class="form-field">';
    echo '<label for="_dmi_mockup_uuid"><strong>Mockup UUID</strong>';
    echo '<span class="dmi-admin-tooltip" title="You can find this in the URL of your template on Dynamic Mockups. It looks like: /catalog/{mockupUUID}/collection/...">❓</span>';
    echo '</label>';
    echo '<input type="text" name="_dmi_mockup_uuid" id="_dmi_mockup_uuid" style="min-width:300px;" value="' . esc_attr($selected_mockup) . '" />';
    echo '</p>';

    // ✅ Smart Object UUID
    echo '<p class="form-field">';
    echo '<label for="_dmi_smartobject_uuid"><strong>Smart Object UUID</strong>';
    echo '<span class="dmi-admin-tooltip" title="You can find this in the URL of your template on Dynamic Mockups. It looks like: /catalog/.../collection/{smartObjectUUID}">❓</span>';
    echo '</label>';
    echo '<input type="text" name="_dmi_smartobject_uuid" id="_dmi_smartobject_uuid" style="min-width:300px;" value="' . esc_attr($selected_smart_object) . '" />';
    echo '</p>';
    echo '</div>';
});

add_action('woocommerce_process_product_meta', function($post_id) {
    // ✅ Save Mockup UUID
    if (isset($_POST['_dmi_mockup_uuid'])) {
        $mockup_uuid = sanitize_text_field($_POST['_dmi_mockup_uuid']);
        update_post_meta($post_id, '_dmi_mockup_uuid', $mockup_uuid);

        $mockups = get_option('dmi_mockup_data', []);
        if (isset($mockups[$mockup_uuid]['thumbnail'])) {
            $thumbnail_url = esc_url_raw($mockups[$mockup_uuid]['thumbnail']);
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';

            $existing_thumbnail_id = get_post_thumbnail_id($post_id);
            if ($existing_thumbnail_id) {
                wp_delete_attachment($existing_thumbnail_id, true);
            }

            $tmp = download_url($thumbnail_url);
            if (!is_wp_error($tmp)) {
                $file_array = [
                    'name'     => basename($thumbnail_url),
                    'tmp_name' => $tmp
                ];

                $attachment_id = media_handle_sideload($file_array, $post_id);

                if (!is_wp_error($attachment_id)) {
                    set_post_thumbnail($post_id, $attachment_id);
                } else {
                    error_log('❌ DMI: Failed to sideload image: ' . $attachment_id->get_error_message());
                }
            } else {
                error_log('❌ DMI: Failed to download thumbnail: ' . $tmp->get_error_message());
            }
        }
    }

    // ✅ Save Smart Object UUID
    if (isset($_POST['_dmi_smartobject_uuid'])) {
        update_post_meta($post_id, '_dmi_smartobject_uuid', sanitize_text_field($_POST['_dmi_smartobject_uuid']));
    }

    // ✅ Save Manufactured at C & C flag
    if (isset($_POST['_dmi_manufactured_at_cnc'])) {
        update_post_meta($post_id, '_dmi_manufactured_at_cnc', 'yes');
    } else {
        delete_post_meta($post_id, '_dmi_manufactured_at_cnc');
    }
});
