<?php
// Shared utility functions
